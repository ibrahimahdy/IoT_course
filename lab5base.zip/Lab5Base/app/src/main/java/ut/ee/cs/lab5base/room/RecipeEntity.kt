package ut.ee.cs.lab5base.room

// the below constructor with title should also be removed!
class RecipeEntity(var title : String) {

}